let posts = [], user = { name:null, avatar:null };
const navToggle = document.getElementById('navToggle'),
      navMenu = document.getElementById('navMenu'),
      sections = document.querySelectorAll('.section'),
      feed = document.getElementById('feedContainer'),
      profileGrid = document.getElementById('profilePosts'),
      avatarIn = document.getElementById('avatarInput'),
      bgPicker = document.getElementById('bgPicker');

navToggle.onclick = () => navMenu.classList.toggle('hidden');

document.querySelectorAll('#navMenu button').forEach(b => 
  b.onclick = () => {
    sections.forEach(s => s.classList.remove('active'));
    document.getElementById(b.dataset.section).classList.add('active');
    navMenu.classList.add('hidden');
    if(b.dataset.section === 'feed') renderFeed();
    if(b.dataset.section === 'profile') renderProfile();
  }
);

avatarIn.onchange = e => {
  const f = e.target.files[0];
  if(f){
    const r = new FileReader();
    r.onload = () => document.getElementById('profileAvatar').src = r.result;
    r.readAsDataURL(f);
  }
};

bgPicker.oninput = e => document.getElementById('profile').style.background = e.target.value;

document.getElementById('postForm').onsubmit = e => {
  e.preventDefault();
  const title = e.target.postTitle.value.trim(),
        summary = e.target.postSummary.value.trim(),
        full = e.target.postFull.value.trim(),
        imgF = e.target.postImage.files[0];
  if(!imgF) return alert('Cover image is required.');
  const r = new FileReader();
  r.onload = () => {
    posts.unshift({ title, summary, full, img:r.result, author: user.name || 'Guest' });
    e.target.reset();
    renderFeed(); renderProfile();
    document.querySelector('[data-section="feed"]').click();
  };
  r.readAsDataURL(imgF);
};

function renderFeed(){
  feed.innerHTML = '';
  posts.forEach((p,i) => {
    const div = document.createElement('div');
    div.className='post';
    div.innerHTML=`
      <img src="${p.img}">
      <h3>${p.title}</h3>
      <p>${p.summary}</p>
    `;
    div.onclick = () => openReader(p);
    feed.appendChild(div);
  });
}

function renderProfile(){
  if(user.name) document.getElementById('profileName').innerText = user.name;
  profileGrid.innerHTML = '';
  posts.filter(p=>p.author===user.name).forEach(p => {
    const d = document.createElement('div');
    d.className='profile-item';
    d.innerHTML=`<img src="${p.img}"><h4>${p.title}</h4>`;
    d.onclick = () => openReader(p);
    profileGrid.appendChild(d);
  });
}

function openReader(p){
  document.getElementById('readerTitle').textContent = p.title;
  document.getElementById('readerImage').src = p.img;
  document.getElementById('readerText').innerText = p.full;
  document.getElementById('readerModal').classList.remove('hidden');
}

document.getElementById('closeModal').onclick = () =>
  document.getElementById('readerModal').classList.add('hidden');